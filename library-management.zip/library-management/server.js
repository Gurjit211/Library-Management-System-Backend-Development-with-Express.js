/**********************************************************************************
 * ITE5315 – Assignment 1
 * I declare that this assignment is my own work in accordance with Humber Academic Policy.
 * No part of this assignment has been copied manually or electronically from any other source
 * (including websites) or distributed to other students.
 * Name: Gurjit Singh Student ID: N01634963 Date: _February 17, 2025
 ***********************************************************************************/

const express = require("express");
const fs = require("fs");
const multer = require("multer");

const app = express();
const PORT = 3000;

// Middleware to parse JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the uploads directory
app.use("/uploads", express.static("uploads"));

// Ensure books.json exists
const BOOKS_FILE = "books.json";
if (!fs.existsSync(BOOKS_FILE)) {
    fs.writeFileSync(BOOKS_FILE, "[]");
}

// Function to load books from books.json
const loadBooks = () => {
    try {
        const data = fs.readFileSync(BOOKS_FILE);
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
};

// Function to save books to books.json
const saveBooks = (books) => {
    fs.writeFileSync(BOOKS_FILE, JSON.stringify(books, null, 2));
};

//  1️⃣ Add a New Book (POST /api/create)
app.post("/api/create", (req, res) => {
    const { isbn, title, author, genre, description, published_year, status } = req.body;

    if (!isbn || !title || !author) {
        return res.status(400).json({ error: "ISBN, title, and author are required!" });
    }

    const books = loadBooks();
    if (books.some(book => book.isbn === isbn)) {
        return res.status(400).json({ error: "ISBN already exists!" });
    }

    const newBook = {
        isbn,
        title,
        author,
        genre,
        description,
        published_year: Number(published_year),
        status: status || "AVAILABLE",
        cover_image: ""
    };

    books.push(newBook);
    saveBooks(books);

    res.status(201).json({ message: "Book added successfully!", book: newBook });
});

//  2️⃣ Get All Books (GET /api/books)
app.get("/api/books", (req, res) => {
    const books = loadBooks();
    const { q, status } = req.query;

    let filteredBooks = books;

    if (q) {
        filteredBooks = filteredBooks.filter(book =>
            book.title.toLowerCase().includes(q.toLowerCase())
        );
    }

    if (status) {
        filteredBooks = filteredBooks.filter(book => book.status.toUpperCase() === status.toUpperCase());
    }

    res.json(filteredBooks);
});

//  3️⃣ Get Book by ISBN (GET /api/books/:isbn)
app.get("/api/books/:isbn", (req, res) => {
    const books = loadBooks();
    const book = books.find(b => b.isbn === req.params.isbn);

    if (!book) {
        return res.status(404).json({ error: "Book not found!" });
    }

    res.json(book);
});

//  4️⃣ Upload Book Cover (POST /api/upload/book-cover)
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
    }
});

const upload = multer({ storage });

app.post("/api/upload/book-cover", upload.single("cover"), (req, res) => {
    if (!req.file || !req.body.isbn) {
        return res.status(400).json({ error: "Image file and ISBN are required!" });
    }

    const books = loadBooks();
    const bookIndex = books.findIndex(book => book.isbn === req.body.isbn);

    if (bookIndex === -1) {
        return res.status(404).json({ error: "Book not found!" });
    }

    books[bookIndex].cover_image = `/uploads/${req.file.filename}`;
    saveBooks(books);

    res.json({ message: "Cover image uploaded!", book: books[bookIndex] });
});

//  5️⃣ Test 500 Error Handling (GET /api/test-error)
app.get("/api/test-error", (req, res, next) => {
    next(new Error("Forced internal server error!")); // This triggers the 500 middleware
});

//  6️⃣ Error Handling Middleware
// 404 Middleware
app.use((req, res, next) => {
    res.status(404).json({ error: "Route not found!" });
});

// 500 Middleware
app.use((err, req, res, next) => {
    console.error("🔥 Internal Server Error:", err.stack);
    res.status(500).json({ error: "Something went wrong!" });
});

// Start Server
app.listen(PORT, () => console.log(`📚 Library Management API running on http://localhost:${PORT}`));

